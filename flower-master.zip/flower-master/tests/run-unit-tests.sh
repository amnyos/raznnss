#!/bin/bash
set -e

python -m tests.unit
